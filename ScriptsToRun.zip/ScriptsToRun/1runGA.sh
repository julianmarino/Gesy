#!/bin/bash

#rodar o total de clientes SOA que serão utilizados.
cd /project/6046773/jmarino/GP_SOFT_COMPUTING/8X8/8x8_1
sbatch UpGASOA.sh



