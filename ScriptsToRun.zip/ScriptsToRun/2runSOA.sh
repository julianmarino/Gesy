#!/bin/bash

total=30

folder="/project/6046773/jmarino/GP_SOFT_COMPUTING/8X8/8x8_1/configSOA/SOA"

for ((m=1; m<=total;m++)) ;  
do
	folder="/project/6046773/jmarino/GP_SOFT_COMPUTING/8X8/8x8_1/configSOA/SOA"$m"/"
	c_used="/project/6046773/jmarino/GP_SOFT_COMPUTING/8X8/8x8_1/commandsUsed/COMM"$m"/"
	echo $folder
	echo $c_used
	#(qsub -l nodes=1:ppn=1,mem=1gb -v FOLDER=$folder UpClientSOA.sh) &
	sbatch --export=FOLDER=$folder,COMMANDS=$c_used UpClientSOA.sh
	sleep 2
done


