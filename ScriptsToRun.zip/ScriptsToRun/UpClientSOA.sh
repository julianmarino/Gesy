#!/bin/bash
#SBATCH --account=def-user
#SBATCH --time=04:00:00
#SBATCH --job-name=SOA_SC_8_2
#SBATCH --cpus-per-task=1
#SBATCH --mem=1G
#SBATCH --output=%x-%j.out

RESULTS=/project/6046773/jmarino/GP_SOFT_COMPUTING/8X8/8x8_1/logs/

#module load java

#/data/apps/java/jre1.8.0_66/bin/java -Xmx4g -XX:ParallelGCThreads=4 -jar MicroRTS.jar ${FOLDER} ${RESULTS} 

java -Xmx2g -XX:ParallelGCThreads=2 -jar MicroRTS.jar  ${FOLDER} ${RESULTS} ${COMMANDS}

