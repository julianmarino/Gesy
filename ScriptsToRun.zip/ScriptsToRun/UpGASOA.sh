#!/bin/bash
#SBATCH --cpus-per-task=2
#SBATCH --mem=2G
#SBATCH --time=4:00:00
#SBATCH --output=%N-%j.out  # %N for node name, %j for jobID
#SBATCH --account=def-lelis

module load java


java -Xmx2g -XX:ParallelGCThreads=2 -jar GA_Scale.jar

